import json
import colorama 
from colorama import Fore, Back, Style 

class ShowStudent:
    # The costructor method
    def __init__(self, json_file):
        self.json_file = json_file
        self.students = self.load_students()
        
        self.check_mark = "\u2705"
        self.envelope = "\u2709"  
        self.cross_mark = "\u274C"  
        self.telephone = "\u260E"

    # Method that loads the students from the file
    def load_students(self):
        try:
            with open('ProjectJSONs/student.json', 'r') as f:
                data = json.load(f)
                students = data.get('students', [])
                if not students:
                    print(Fore.YELLOW + "\n ⚠️ Warning: No students found in JSON file"+Style.RESET_ALL)
                return students
            
        except json.JSONDecodeError as e:
            print(Fore.YELLOW + "\n ⚠️ Error: Invalid JSON format in file: {str(e)}"+Style.RESET_ALL)
            return []
        except Exception as e:
            print(Fore.YELLOW + f"\n ⚠️ Error reading file! Please Make Sure you have created a student already!: {str(e)}" + Style.RESET_ALL)
            return []

    # The menu to give the user search options
    def search_by_menu(self):
        while True:
            print(Fore.LIGHTMAGENTA_EX + "\n=== Student Management System ===" + Style.RESET_ALL)
            print("1. Show All Students")
            print("2. Search by Name")
            print("3. Search by ID")
            print("4. Search by Major")
            print("5. To Exit")
            
            choice = input("\nEnter your choice (1-5): ")
            
            if choice == '1':
                self.display_all_students()
            elif choice == '2':
                self.search_by_name()
            elif choice == '3':
                self.search_by_id()
            elif choice == '4':
                self.filter_by_major()
            elif choice == '5':
                print(Fore.RED + "Exiting" + Style.RESET_ALL)
                break
            else:
                print(Fore.RED + "\n❌Invalid choice. Please try again."+Style.RESET_ALL)

    # Method to print out students individually
    def display_student(self, student):
        if student:
            print(f"{student['id']:<12}"
                f"{student['name']:<15}"
                f"{student['age']:<5}"
                f"{student['gender']:<8}"
                f"{student['major']:<8}"
                f"{student['gpa']:<7}"
                f"{student['phone']:<15}")

    # 1. Show all students
    # Method to display all of the students
    def display_all_students(self):
        print("=" * 60)
        print(f"{'ID':<12}{'Name':<15}{'Age':<5}{'Gender':<8}{'Major':<8}{'GPA':<7}{'Phone':<15}")
        print("=" * 60)
    
        if not self.students:
            print(Fore.RED + "\n❌ No students found." +Style.RESET_ALL)
            return
        
        for student in self.students:
            print(f"{student['id']:<12}"
                f"{student['name']:<15}"
                f"{student['age']:<5}"
                f"{student['gender']:<8}"
                f"{student['major']:<8}"
                f"{student['gpa']:<7}"
                f"{student['phone']:<15}")
    
        print("=" * 60)

    # 2. Search by Name
    # Method that allows the user to search the database by name 
    def search_by_name(self):
        name = input("\nEnter student name to search: ").strip().upper()
        found = False
        print(Back.LIGHTBLACK_EX + "=" * 60 + Style.RESET_ALL)
        print(f"{'ID':<12}{'Name':<15}{'Age':<5}{'Gender':<8}{'Major':<8}{'GPA':<7}{'Phone':<15}")
        print(Back.LIGHTBLACK_EX + "=" * 60 + Style.RESET_ALL)
        for student in self.students:
            if student['name'].upper().find(name) != -1:
                self.display_student(student)
                found = True
        if not found:
            print(Fore.RED + f"\n❌ No students found with name containing '{name}'"+Style.RESET_ALL)

    # 3. Search by ID
    # Method that allows the user to search by the id
    def search_by_id(self):
        student_id = input("\nEnter student ID: ").strip()
        found = False
        print(Back.LIGHTBLACK_EX + "=" * 60 + Style.RESET_ALL)
        print(f"{'ID':<12}{'Name':<15}{'Age':<5}{'Gender':<8}{'Major':<8}{'GPA':<7}{'Phone':<15}")
        print(Back.LIGHTBLACK_EX + "=" * 60 + Style.RESET_ALL)
        for student in self.students:
            if student['id'] == student_id:
                self.display_student(student)
                found = True
                break
        if not found:
            print(Fore.RED + f"\n❌ No student found with ID: {student_id}"+Style.RESET_ALL)

    # 4. Search by major
    # Method that allows the user to earch by major
    def filter_by_major(self):
        print("\nAvailable majors:")
        majors = set(student['major'] for student in self.students)
        for major in majors:
            print(f"* {major}")
        while True:
            major = input("\nEnter the major to filter by (or press Enter to see all students): ").strip().upper()
            print(f"\n=== {major} Students ===")
            print(Back.LIGHTBLACK_EX + "=" * 60 + Style.RESET_ALL)
            print(f"{'ID':<12}{'Name':<15}{'Age':<5}{'Gender':<8}{'Major':<8}{'GPA':<7}{'Phone':<15}")
            print(Back.LIGHTBLACK_EX + "=" * 60 + Style.RESET_ALL)
            if not major:
                self.display_all_students()
                break
            elif major.upper() in {m.upper() for m in majors}:
                self.display_filtered_students(major)
                break
            else:
                print(Fore.RED + "\n❌ Invalid major. Please try again."+Style.RESET_ALL)
    # Method that filters the students by their major
    def display_filtered_students(self, major=None):
        filtered_students = self.students
        if major:
            filtered_students = [student for student in self.students 
                               if student['major'].upper() == major.upper()]
        if not filtered_students:
            print(Fore.RED + f"\n❌ No students found" + (f" with major {major}." if major else ".")+Style.RESET_ALL)
            return
        for student in filtered_students:
            self.display_student(student)

    

 
